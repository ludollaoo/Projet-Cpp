#include "affichage.hh"

void afficher_chiffre(const std::vector<int> tab){

	 SDL_Surface *ecran = NULL, *lignes[784] = {NULL};

    SDL_Rect position;

    int i = 0;


    SDL_Init(SDL_INIT_VIDEO);


    ecran = SDL_SetVideoMode(280, 280, 32, SDL_HWSURFACE);


    for (i = 0 ; i <= 784 ; i++)

        lignes[i] = SDL_CreateRGBSurface(SDL_HWSURFACE, 10, 10, 32, 0, 0, 0, 0);


    SDL_WM_SetCaption("Mon tableau de merde en SDL !", NULL);


    SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 0, 0, 0));


    for (i = 0 ; i <= 784 ; i++)

    {

        position.x = (i%28)*10;

        position.y = (i/28)*10;
        
        SDL_FillRect(lignes[i], NULL, SDL_MapRGB(ecran->format, tab[i], tab[i], tab[i]));

        SDL_BlitSurface(lignes[i], NULL, ecran, &position);

    }


    SDL_Flip(ecran);

    pause();


    for (i = 0 ; i <= 784 ; i++) // N'oubliez pas de libérer les 256 surfaces

        SDL_FreeSurface(lignes[i]);

    SDL_Quit();
}
 
void pause()
{
    int continuer = 1;
    SDL_Event event;
 
    while (continuer)
    {
        SDL_WaitEvent(&event);
        switch(event.type)
        {
            case SDL_QUIT:
                continuer = 0;
        }
    }
}
