#include "Reseau_Neurones.hh"

Reseau_Neurones::Reseau_Neurones(int nb_couche_intermediaire, int nb_neurones_par_couche, float learning_rate): learning_rate(learning_rate){

	//création de la couche d'entrée (par défaut), les Neurones de cette couche ne sont pas reliés
	std::cout << "couche n°0 créée" << std::endl;
	tab_couche.push_back(Couche(784));
	int i;
	
	//création des couches intermédiaires
	for(i = 0; i < nb_couche_intermediaire; i++){
		std::cout << "couche n°" << i+1 << " créée à partir de couche n°" << i << std::endl;
		//toutes ces Couches sont connectés à la Couche précédente grçace au constructeur de Couche
		tab_couche.push_back(Couche(nb_neurones_par_couche, tab_couche[i]));
	}
	
	//création de la couche de sortie, les Neurones de cette couche sont reliés aux Neurones de la couche précédente
	std::cout << "couche n°" << i+1 << " créée à partir de couche n°" << i << std::endl;
	tab_couche.push_back(Couche(10, tab_couche[i]));
}

std::vector<Couche>& Reseau_Neurones::getTab_couche(){
	return tab_couche;
}

void Reseau_Neurones::chargerReseau(std::vector<int> tab){
	if(tab.size() != 784){
		std::cout << "Le tableau n'est pas de la bonne taille" << std::endl;
		return;
	}
	for(int i = 0; i < 784; i++){
		tab_couche[0].getTab_neurone()[i].setZ(tab[i]);
		//std::cout << tab[i] << " " << tab_couche[0].getTab_neurone()[i].getValeur() << std::endl;
	}
}

void Reseau_Neurones::calculerReseau(){
	for(size_t i = 0; i < tab_couche.size(); i++){
		tab_couche[i].calculerCouche();
	}
}

std::vector<float> Reseau_Neurones::getResultats(){
	std::vector<float> res;
	int i = tab_couche.size();
	for(Neurone neurone : tab_couche[i-1].getTab_neurone()){
		res.push_back(neurone.getValeur());
	}
	return res;
}

std::ostream& operator<<(std::ostream& flux, Reseau_Neurones & reseau){
	for(size_t i = 0; i < 784; i++){
		for(Couche &couche : reseau.getTab_couche()){
			if(i < couche.getTab_neurone().size()){
				flux << couche.getTab_neurone()[i].getValeur() << "		";
			}
		}
		flux << std::endl;
	}
	return flux;
}

std::vector<float> Reseau_Neurones::calculGradient(int label){
	std::vector<float> gradient;
	std::vector<float> influence_neurones_couche_courante(10), influence_neurones_couche_precedente(10);
	
	//on parcourt les couches à l'envers
	for(size_t i = tab_couche.size() - 1; i > 0; i--){
		Couche& couche_courante = tab_couche[i];
		//std::cout << "calcul du gradient pour la couche n°" << i << std::endl;
		
		if(i == tab_couche.size() -1){ //on se situe sur la derniere couche
		
			//on initialise influence_neurones_couche_courante 
			for(int j = 0; j < 10; j++){
				float val_neurone = couche_courante.getTab_neurone()[j].getValeur();
				if(j == label){
					influence_neurones_couche_courante[j] = 2*(val_neurone - 1);
				}else{	
					influence_neurones_couche_courante[j] = 2*(val_neurone - 0);
				}
			}
		}else{ //on se situe sur une couche quelconque 
			//on transfert les valeurs
			Couche& couche_precedente = tab_couche[i+1];
			influence_neurones_couche_precedente = influence_neurones_couche_courante;
			influence_neurones_couche_courante.resize(couche_courante.getTab_neurone().size());
						
			//on calcule les nouvelles influences des neurones
			for(size_t j = 0; j < influence_neurones_couche_courante.size(); j++){
				//valeur final de l'influence du neurone
				float temp = 0;
				for(size_t k = 0; k < influence_neurones_couche_precedente.size(); k++){//parcours des anciennes valeurs
					Neurone& neurone_couche_precedente = couche_precedente.getTab_neurone()[k];
					//somme 
					temp += neurone_couche_precedente.getPoids(j+1)*fonction_sigmoide_prime(neurone_couche_precedente.getZ())*influence_neurones_couche_precedente[k];
				}
				influence_neurones_couche_courante[j] = temp;
			} 
		}
		
		/*std::cout << "influence des neurones de la couche : " << i << std::endl;
		for(float val : influence_neurones_couche_courante){
			std::cout << val << " ";
		}
		std::cout << std::endl;*/ 
		
		//calcul du gradient
		for(size_t k = 0; k < couche_courante.getTab_neurone().size(); k++){ //on parcourt chaque neurone
					
			Neurone& neurone_courant = couche_courante.getTab_neurone()[k];
		 
		   //calcul de l'influence de z
			float influence_z = fonction_sigmoide_prime(neurone_courant.getZ());
			
			//on calcul l'influence du biais
			float influence_biais = influence_z * influence_neurones_couche_courante[k];
			//on ajoute la valeur au vecteur gradient
			gradient.push_back(influence_biais);

			for(size_t j = 1; j < neurone_courant.getTab_poids().size(); j++){ //on parcourt chaque poids pour calculer leur influence
				float valeur_neurone_prec = neurone_courant.getLien()[j-1]->getValeur();
				float influence_poids = valeur_neurone_prec * influence_biais;
				//on ajoute la valeur au vecteur gradient
				gradient.push_back(influence_poids);
			}
		}
	}
		
	return gradient;
}

int Reseau_Neurones::calculNbParametres(){
	int nb_parametres = 0;
	for(Couche& couche : tab_couche){
		for(Neurone& neurone : couche.getTab_neurone()){
			nb_parametres += neurone.getTab_poids().size();
		}
	}
	return nb_parametres;
}

void Reseau_Neurones::corrigerParametres(std::vector<float> gradient){
	if(gradient.size() != (size_t)this->calculNbParametres()){
		std::cout << "le tableau fournit n'est pas de la bonne longueur" << std::endl;
		return;
	}
	int j = 0;
	for(size_t i = tab_couche.size() - 1; i > 0; i--){
		for(Neurone& neurone : tab_couche[i].getTab_neurone()){
			for(float& poids : neurone.getTab_poids()){
				poids += -gradient[j]*learning_rate;
				j++;
			}
		}
	}
}

void Reseau_Neurones::entrainerReseau(){
	//ouverture des fichiers d'entrainement
	std::ifstream ifs_label = ouvrir_ifs_label();
	std::ifstream ifs_image = ouvrir_ifs_image();
	
	int label; 
	std::vector<int> vect_image(784);
	
	int cpt_batch = 0;
	while((!ifs_label.eof()) && (!ifs_label.eof())){
		std::cout << "mini batch n°" << cpt_batch << std::endl;
		cpt_batch++;
		 
		std::vector<float> gradient_moyen(this->calculNbParametres());
		std::vector<float> gradient(this->calculNbParametres());
		for(int cpt_image = 0; cpt_image < 100; cpt_image++){
		 
		 	label = ifs_label.get();
		 	for(int i = 0; i < 784; i++){
				vect_image[i] = ifs_image.get() - 122;
			}
			this->chargerReseau(vect_image);
			this->calculerReseau();
			gradient = this->calculGradient(label);
			
			for(size_t i = 0; i < gradient.size(); i++){
				gradient_moyen[i] += gradient[i];
			}
			/*
			//suivit de l'algorithme
			std::cout << "label" << label << std::endl;
			Neurone neurone30 = this->getTab_couche()[3].getTab_neurone()[0];
			std::cout << neurone30 << std::endl;
			std::cout << "gradient :" << std::endl;
			for(int i = 0; i < 17; i++){
				std::cout << gradient[i] << " ";
			}
			std::cout << std::endl;
			std::cin.get();*/
		}
		int nb_p, nb_n;
		float j, somme_p, somme_n;
		nb_p = 0;
		nb_n = 0;
		somme_p = 0;
		somme_n = 0;
		for(size_t i = 0; i < gradient_moyen.size(); i++){
			j = gradient_moyen[i];
			if(j > 0){ somme_p += j; nb_p++;}
			if(j < 0){ somme_n += j; nb_n++;}
		}
		std::cout << "nombre de corrections positives : " << nb_p << " , somme totale : " << somme_p << std::endl;
		std::cout << "nombre de corrections négatives : " << nb_n << " , somme totale : " << somme_n << std::endl;
		std::cout << " différence : " << somme_p + somme_n << std::endl << std::endl;
		this->corrigerParametres(gradient_moyen);
	}
}













