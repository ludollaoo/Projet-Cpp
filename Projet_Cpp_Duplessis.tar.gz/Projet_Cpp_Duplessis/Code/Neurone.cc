#include <cstdlib>
#include "Neurone.hh"

Neurone::Neurone(std::vector<Neurone*> tab_Neurone): 
valeur(0),
z(0), 
poids(tab_Neurone.size() + 1), 
lien(tab_Neurone) {
	
	for(size_t i = 0; i < lien.size() + 1; i++){
		poids[i] = rand() % 3 - 1.5;
	}
}

Neurone::Neurone():
valeur(0),
z(0),
poids(),
lien() {}

float Neurone::getValeur(){
	return valeur;
}

float Neurone::getZ(){
	return z;
}

std::vector<float>& Neurone::getTab_poids(){
	return poids;
}

float Neurone::getPoids(int indice){
	return poids[indice];
}

std::vector<Neurone*> Neurone::getLien(){
	return lien;
}

void Neurone::setPoids(int indice, float val){
	poids[indice] = val;
}

void Neurone::setValeur(float val){
	valeur = val;
}

void Neurone::setZ(float val){
	z = val;
}

std::ostream& operator<<(std::ostream& flux, Neurone & neurone){
	flux << "adresse : " << &neurone << std::endl;
	flux << "z : " << neurone.getZ() << std::endl;
	flux << "valeur : " << neurone.getValeur() << std::endl;
	flux << "biais : ";
	if(neurone.getLien().size() != 0){
		flux << neurone.getPoids(0);
	}
	flux << std::endl;
	
	flux << "connection (valeur, poids) : " << std::endl;
	for(size_t i = 0; i < neurone.getLien().size(); i++){
		flux << "(" << (neurone.getLien()[i])->getValeur() << ", " << neurone.getPoids(i+1) << ") ";
	}
	flux << std::endl;
	return flux;
}

void Neurone::calculerValeur(){
	if(lien.size() != 0){
		z = poids[0];
	}
	for(size_t i = 0; i < lien.size(); i++){
		z += poids[i+1] * lien[i]->getValeur();
	}
	valeur = fonction_sigmoide(z);
}

/*int main(){
	srand(time(NULL));
	
	Neurone neurone00, neurone01;
	neurone00.setValeur(2.0);
	neurone01.setValeur(-3.0);
	std::vector<Neurone*> tab_neurone;
	tab_neurone.push_back(&neurone00);
	tab_neurone.push_back(&neurone01);
	
	Neurone neurone10(tab_neurone);
	std::cout << neurone10.getPoids(0) << " " << neurone10.getPoids(1) << std::endl;
	
	neurone10.calculerValeur();
	std::cout << neurone10.getValeur() << std::endl;
	std::cout << neurone10 << std::endl;	 
}*/
