#include "donnees.hh"
#include "affichage.hh"
#include "Couche.hh"

class Reseau_Neurones{
	private:
	float learning_rate;
	std::vector<Couche> tab_couche;
	
	public:
	Reseau_Neurones(int, int, float);
	void chargerReseau(std::vector<int>);
	void calculerReseau();
	std::vector<Couche>& getTab_couche();
	std::vector<float> getResultats();
	friend std::ostream& operator<<(std::ostream&, Reseau_Neurones&);
	std::vector<float> calculGradient(int label);
	int calculNbParametres();
	void corrigerParametres(std::vector<float>);
	void entrainerReseau();
};
