#include <vector>
#include <math.h>
#include <iostream>

class Neurone{
	private:
	float valeur;
	float z;
	std::vector<float> poids;
	std::vector<Neurone*> lien;
	
	public:
	//constructeurs
	Neurone(std::vector<Neurone*>);
	Neurone();
	
	//getters
	float getValeur();
	float getZ();
	std::vector<float>& getTab_poids();
	float getPoids(int);
	std::vector<Neurone*> getLien();
	
	//setters
	void setValeur(float);
	void setPoids(int, float);
	void setZ(float);
	
	//affichages
	friend std::ostream& operator<<(std::ostream&, Neurone&);
	
	//methodes
	void calculerValeur();
};

//maths
inline float fonction_sigmoide(float x){ return 1/(1 + exp(-0.5*x));}

inline float fonction_sigmoide_prime(float x){return 0.5*fonction_sigmoide(x)*(1 - fonction_sigmoide(x));}

inline float ReLU(float x){ 
	if (x > 0){ return x;}
	else{return 0;}
}

inline float ReLU_prime(float x){
	if(x > 0){ return 1;}
	else{return 0;}
}



