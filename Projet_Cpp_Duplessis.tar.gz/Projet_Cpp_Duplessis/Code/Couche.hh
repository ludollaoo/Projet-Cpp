#include "Neurone.hh"

class Couche{
	private:
	std::vector<Neurone> tab_neurone;
	
	public:
	Couche(int);
	Couche(int, Couche&);
	std::vector<Neurone>& getTab_neurone();
	friend std::ostream& operator<<(std::ostream&, Couche&);
	void calculerCouche();
};
