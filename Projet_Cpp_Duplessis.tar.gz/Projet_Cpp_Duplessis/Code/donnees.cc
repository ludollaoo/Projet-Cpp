#include "donnees.hh"

std::ifstream ouvrir_ifs_label(){
	std::ifstream flux("../Données/train-labels.idx1-ubyte");
	
	for(int i = 0; i < 8; i++){
		std::cout << flux.get();
	}
	std::cout << std::endl;
	return flux;
}

std::ifstream ouvrir_ifs_image(){
	std::ifstream flux("../Données/train-images.idx3-ubyte");
	for(int i = 0; i < 16; i++){
		std::cout << flux.get();
	}
	std::cout << std::endl;
	return flux;
}
