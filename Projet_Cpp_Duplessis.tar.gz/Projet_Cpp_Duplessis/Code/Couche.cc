#include "Couche.hh"
#include <cstdlib>

Couche::Couche(int nb_neurone): tab_neurone(nb_neurone){
	std::cout << "couche " << this << " créée par défaut" << std::endl;
}

Couche::Couche(int nb_neurone, Couche &couche_precedente): tab_neurone(nb_neurone){
	std::vector<Neurone*> lien;
	int i = 0;
	for(Neurone neurone_precedent : couche_precedente.getTab_neurone()){
		lien.push_back(&couche_precedente.getTab_neurone()[i]);
		i++;
	}
	
	for(size_t i = 0; i < tab_neurone.size(); i++){
		tab_neurone[i] = Neurone(lien);
	}
	std::cout << "couche " << this << "créée à partir de la couche " << &couche_precedente << std::endl;
}
	
	
std::vector<Neurone>& Couche::getTab_neurone(){
	return tab_neurone;
}

std::ostream& operator<<(std::ostream& flux, Couche & couche){
	for(Neurone neurone : couche.getTab_neurone()){
		flux << neurone.getValeur() << std::endl;
	}
	return flux;
}

void Couche::calculerCouche(){
	/*if(tab_neurone.size() == 0){return;}
	for(Neurone& neurone : tab_neurone){
	
		neurone.calculerValeur();
	}*/
	for(size_t i = 0; i < tab_neurone.size(); i++){
		tab_neurone[i].calculerValeur();
	}
}

/*int main(){
	srand(time(NULL));
	
	Couche couche0(10);
	for(int i = 0; i < couche0.getTab_neurone().size(); i++){
		std::cout << i << " " << &couche0.getTab_neurone()[i] << " ";
		couche0.getTab_neurone()[i].setValeur(i);
		std::cout << couche0.getTab_neurone()[i] << std::endl;
	}
	
	Couche couche1(10, couche0);
	couche1.calculerCouche();
	for(int i = 0; i < couche1.getTab_neurone().size(); i++){
		std::cout << couche1.getTab_neurone()[i] << std::endl;
	}
	
	Couche couche2(10, couche1);
	couche1.calculerCouche();
	for(int i = 0; i < couche1.getTab_neurone().size(); i++){
		std::cout << couche1.getTab_neurone()[i].getValeur() << " ";
	}
	std::cout << std::endl;
	
}*/
