#include "Reseau_Neurones.hh"

int main(){

	srand(time(NULL));

	//creation d'un reseau de quatre couches ayant respectivement 784, 16, 16, 10 neurones
	std::cout << "creation reseau de neurones" << std::endl;
	Reseau_Neurones reseau0(2, 16, 1);
	std::cout << "reseau de neurones cree" << std::endl;
	
	//entrainements sur les 60 000 images (environs 10min)
	reseau0.entrainerReseau();
	
	//affichage des résultats pour les 10 premières images
	int label; 
	std::vector<int> vect_image(784);
	std::ifstream ifs_label = ouvrir_ifs_label();
	std::ifstream ifs_image = ouvrir_ifs_image();
	
	for(int j = 0; j < 10; j++){
	
		std::cout << "Image n°" << j << std::endl;
		label = ifs_label.get();
		std::cout << "nombre : " << label << std::endl;
		for(int i = 0; i < 784; i++){
			vect_image[i] = ifs_image.get() - 122;
			
		}
		reseau0.chargerReseau(vect_image);
		reseau0.calculerReseau();
		std::cout << reseau0.getTab_couche()[3] << std::endl;
		afficher_chiffre(vect_image);
	}








	
	/*int label; 
	std::vector<int> vect_image(784);
	std::vector<float> vect_resultat(10);
	
	//srand(time(NULL));
	std::cout << "creation reseau de neurones" << std::endl;
	Reseau_Neurones reseau0(2, 6, 1);
	std::cout << "reseau de neurones cree" << std::endl;
	
	for(int j = 0; j < 2; j++){
	
		std::ifstream ifs_label = ouvrir_ifs_label();
		std::ifstream ifs_image = ouvrir_ifs_image();
		
		std::cout << "Image n°" << j << std::endl;
		label = ifs_label.get();
		std::cout << "nombre : " << label << std::endl;
		for(int i = 0; i < 784; i++){
			vect_image[i] = ifs_image.get();
			
		}
		reseau0.chargerReseau(vect_image);
		reseau0.calculerReseau();
		std::cout << reseau0.getTab_couche()[3] << std::endl;
		
		std::vector<float> gradient;
		gradient = reseau0.calculGradient(label);
		for(float val :gradient){
			std::cout << 1000*val << " ";
		}
		std::cout << std::endl;
		reseau0.corrigerParametres(gradient);
		afficher_chiffre(vect_image);
	}*/
}
