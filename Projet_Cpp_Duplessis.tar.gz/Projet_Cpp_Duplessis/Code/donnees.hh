#include <fstream>
#include <iostream>

std::ifstream ouvrir_ifs_label();
std::ifstream ouvrir_ifs_image();
