#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <SDL/SDL.h>

void afficher_chiffre(const std::vector<int>);
void pause();
